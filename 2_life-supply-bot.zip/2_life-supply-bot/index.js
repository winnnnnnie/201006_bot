require("dotenv").config();

const express = require("express");
const { LineBotClient, middleware } = require("@line/bot-sdk");

const { Client } = require("@notionhq/client");

const app = express();

const lineClient = LineBotClient.fromChannelAccessToken({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
});

const notion = new Client({
  auth: process.env.NOTION_TOKEN,
});

const NOTION_DATA_SOURCE_ID = "3f029588-2033-80c3-a4c8-000b6406e0d6";
// ==============================
// 判斷訊息意圖
// ==============================

function detectIntent(message) {
  const text = message.trim();

  // ① 已經買了／有庫存
  if (
    text.includes("買了") ||
    text.includes("買好") ||
    text.includes("剛買") ||
    text.includes("補貨了")
  ) {
    return {
      intent: "stocked",
      status: "現在不用買",
    };
  }

  // ② 快沒了
  if (
    text.includes("快沒") ||
    text.includes("快用完") ||
    text.includes("剩不多") ||
    text.includes("快沒有")
  ) {
    return {
      intent: "running_low",
      status: "快沒了",
    };
  }

  // ③ 沒了／要買
  if (
    text.includes("沒了") ||
    text.includes("用完") ||
    text.includes("要買") ||
    text.includes("需要買")
  ) {
    return {
      intent: "need_to_buy",
      status: "要購買",
    };
  }

  // ④ 想買／研究
  if (
    text.includes("想買") ||
    text.includes("想研究") ||
    text.includes("考慮買") ||
    text.includes("想要")
  ) {
    return {
      intent: "research",
      status: "想研究",
    };
  }

  // ⑤ 無法判斷
  return {
    intent: "unknown",
    status: null,
  };
}
// ==============================
// 擷取用品名稱
// ==============================

function extractItemName(message) {
  let text = message.trim();

  // 移除常見的狀態／意圖文字
  const removeWords = [
    "快沒了",
    "快用完了",
    "剩不多了",
    "快沒有了",
    "沒有了",
    "沒了",
    "用完了",
    "要買",
    "需要買",
    "想買",
    "想研究",
    "考慮買",
    "想要",
    "買了",
    "買好了",
    "剛買了",
    "補貨了",
    "我",
    "我要",
    "我想",
    "我剛",
  ];

  for (const word of removeWords) {
    text = text.replace(word, "");
  }

  return text.trim();
}
function detectCategory(itemName) {
  const text = itemName.toLowerCase();

  if (
    text.includes("衛生紙") ||
    text.includes("垃圾袋") ||
    text.includes("清潔劑") ||
    text.includes("洗衣精") ||
    text.includes("洗碗精") ||
    text.includes("抹布")
  ) {
    return "居家";
  }

  if (
    text.includes("洗面乳") ||
    text.includes("洗髮") ||
    text.includes("沐浴") ||
    text.includes("牙膏") ||
    text.includes("化妝")
  ) {
    return "個人";
  }

  if (
    text.includes("色鉛筆") ||
    text.includes("水彩") ||
    text.includes("油畫") ||
    text.includes("畫筆") ||
    text.includes("畫紙") ||
    text.includes("素描") ||
    text.includes("顏料")
  ) {
    return "藝術／創作";
  }

  if (
    text.includes("鍵盤") ||
    text.includes("滑鼠") ||
    text.includes("耳機") ||
    text.includes("充電") ||
    text.includes("硬碟") ||
    text.includes("ipad") ||
    text.includes("iphone")
  ) {
    return "3C／數位";
  }

  if (
    text.includes("衣服") ||
    text.includes("鞋") ||
    text.includes("襪") ||
    text.includes("外套")
  ) {
    return "穿戴";
  }

  if (
    text.includes("咖啡") ||
    text.includes("茶") ||
    text.includes("餅乾") ||
    text.includes("牛奶") ||
    text.includes("泡麵")
  ) {
    return "食品";
  }

  return "其他";
}
// ==============================
// 分析完整訊息
// ==============================

function analyzeMessage(message) {
  const intentResult = detectIntent(message);
  const itemName = extractItemName(message);
  const category = detectCategory(itemName);

  return {
    name: itemName,
    category: category,
    status: intentResult.status,
    intent: intentResult.intent,
    brand: null,
    spec: null,
    store: null,
    note: null,
  };
}

// ==============================
// 回覆文字
// ==============================

function createReply(message) {
  const data = analyzeMessage(message);

  console.log("原始訊息：", message);
  console.log("分析結果：", data);

  switch (data.intent) {
    case "stocked":
      return `🟢 有庫存
用品：${data.name}
分類：${data.category}`;

    case "running_low":
      return `🟡 快沒了
用品：${data.name}
分類：${data.category}`;

    case "need_to_buy":
      return `🛒 要購買
用品：${data.name}
分類：${data.category}`;

    case "research":
      return `💭 想研究
用品：${data.name}
分類：${data.category}`;

    default:
      return `🤔 我還不知道這句話要做什麼：\n\n${message}`;
  }
}
async function findNotionItem(itemName) {
  console.log("🔍 開始搜尋 Notion：", itemName);

  try {
    const response = await notion.dataSources.query({
      data_source_id: NOTION_DATA_SOURCE_ID,
      filter: {
        property: "名稱",
        title: {
          equals: itemName,
        },
      },
    });

    console.log("🔍 Notion 搜尋結果數量：", response.results.length);

    if (response.results.length > 0) {
      console.log("✅ 找到既有用品：", itemName);
      console.log("Page ID：", response.results[0].id);

      return response.results[0];
    }

    console.log("🆕 Notion 沒找到，準備新增：", itemName);

    return null;
  } catch (error) {
    console.error("❌ Notion 搜尋失敗：");
    console.error(error);
    throw error;
  }
}

async function createOrUpdateNotionItem(data) {
  const existingItem = await findNotionItem(data.name);

  // ==============================
  // 已經存在 → 更新
  // ==============================

  if (existingItem) {
    console.log("🔄 準備更新用品：", data.name);
    console.log("➡️ 新狀態：", data.status);

    await notion.pages.update({
      page_id: existingItem.id,

      properties: {
        庫存狀態: {
          status: {
            name: data.status,
          },
        },

        選取: {
          select: {
            name: data.category,
          },
        },
      },
    });

    console.log("✅ Notion 更新成功：", data.name);

    return {
      action: "updated",
      pageId: existingItem.id,
    };
  }

  // ==============================
  // 不存在 → 新增
  // ==============================

  console.log("🆕 準備新增用品：", data.name);

  const response = await notion.pages.create({
    parent: {
      data_source_id: NOTION_DATA_SOURCE_ID,
    },

    properties: {
      名稱: {
        title: [
          {
            text: {
              content: data.name,
            },
          },
        ],
      },

      庫存狀態: {
        status: {
          name: data.status,
        },
      },

      選取: {
        select: {
          name: data.category,
        },
      },

      購買注意事項: {
        rich_text: [],
      },
    },
  });

  console.log("✅ Notion 新增成功：", data.name);

  return {
    action: "created",
    pageId: response.id,
  };
}

// ==============================
// 首頁測試
// ==============================

app.get("/", (req, res) => {
  res.send("Life Supply Bot is running!");
});

// ==============================
// LINE Webhook
// ==============================

app.post(
  "/webhook",
  middleware({
    channelSecret: process.env.LINE_CHANNEL_SECRET,
  }),
  async (req, res) => {
    res.sendStatus(200);

    for (const event of req.body.events) {
      if (event.type !== "message" || event.message.type !== "text") {
        continue;
      }

      const userMessage = event.message.text;

      console.log("收到 LINE 訊息：", userMessage);

      try {
        const data = analyzeMessage(userMessage);

        console.log("① 分析完成：", data);

        if (data.intent !== "unknown" && data.name) {
          console.log("② 通過條件，準備呼叫 Notion");

          const notionResult = await createOrUpdateNotionItem(data);

          console.log("③ Notion 操作結果：", notionResult);
        } else {
          console.log("❌ 沒有通過 Notion 條件");
          console.log("intent =", data.intent);
          console.log("name =", data.name);
        }

        const replyText = createReply(userMessage);

        await lineClient.replyMessage({
          replyToken: event.replyToken,
          messages: [
            {
              type: "text",
              text: replyText,
            },
          ],
        });
      } catch (error) {
        console.error("LINE 回覆失敗：", error);
      }
    }
  },
);

// ==============================
// 啟動伺服器
// ==============================

const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Life Supply Bot running on port ${port}`);
});
