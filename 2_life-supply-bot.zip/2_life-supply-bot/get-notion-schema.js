require("dotenv").config();

const { Client } = require("@notionhq/client");

const notion = new Client({
  auth: process.env.NOTION_TOKEN,
});

const dataSourceId = "3f029588-2033-80c3-a4c8-000b6406e0d6";

async function getSchema() {
  try {
    const response = await notion.dataSources.retrieve({
      data_source_id: dataSourceId,
    });

    console.log("✅ Data Source 取得成功！");
    console.log("名稱：", response.name);
    console.log("");

    console.log("📋 Notion 實際欄位：");
    console.log("");

    for (const [name, property] of Object.entries(response.properties)) {
      console.log(`欄位名稱：${name}`);
      console.log(`類型：${property.type}`);
      console.log(`ID：${property.id}`);
      console.log("------------------------");
    }

  } catch (error) {
    console.error("❌ 取得 Schema 失敗：");
    console.error(error.message);
  }
}

getSchema();