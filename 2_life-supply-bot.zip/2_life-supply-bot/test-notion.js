require("dotenv").config();

const { Client } = require("@notionhq/client");

const notion = new Client({
  auth: process.env.NOTION_TOKEN,
});

async function testNotion() {
  try {
    const response = await notion.databases.retrieve({
      database_id: process.env.NOTION_DATABASE_ID,
    });

    console.log("✅ Notion Database 連線成功！");
    console.log("Database ID：", response.id);
    console.log("Database Object：", response.object);
    console.log("");

    console.log("完整回傳資料：");
    console.log(JSON.stringify(response, null, 2));
  } catch (error) {
    console.error("❌ Notion API 錯誤：");
    console.error(error.message);
  }
}

testNotion();