require("dotenv").config();

const { Client } = require("@notionhq/client");

const notion = new Client({
  auth: process.env.NOTION_TOKEN,
});

const dataSourceId = "3f029588-2033-80c3-a4c8-000b6406e0d6";

async function createTestItem() {
  try {
    const response = await notion.pages.create({
      parent: {
        data_source_id: dataSourceId,
      },

      properties: {
        "名稱": {
          title: [
            {
              text: {
                content: "衛生紙",
              },
            },
          ],
        },

        "庫存狀態": {
          status: {
            name: "快沒了",
          },
        },

        "選取": {
          select: {
            name: "居家",
          },
        },

        "購買注意事項": {
          rich_text: [
            {
              text: {
                content: "測試：LINE Bot 新增",
              },
            },
          ],
        },
      },
    });

    console.log("🎉 成功新增 Notion 資料！");
    console.log("Page ID：", response.id);
  } catch (error) {
    console.error("❌ Notion 新增失敗：");
    console.error(error.message);
  }
}

createTestItem();