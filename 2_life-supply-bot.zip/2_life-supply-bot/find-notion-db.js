require("dotenv").config();

const { Client } = require("@notionhq/client");

const notion = new Client({
  auth: process.env.NOTION_TOKEN,
});

const id = "3f029588203380c3932cdaad19580dfe";

async function checkNotion() {
  console.log("開始檢查 Notion ID...");
  console.log("ID：", id);
  console.log("");

  // ① 先當作 Page ID
  try {
    const page = await notion.pages.retrieve({
      page_id: id,
    });

    console.log("✅ 這個 ID 是 Page！");
    console.log("Page ID：", page.id);
    console.log("Page URL：", page.url);
    console.log("");
  } catch (error) {
    console.log("❌ 不是 Page ID");
    console.log("");
  }

  // ② 再當作 Database ID
  try {
    const database = await notion.databases.retrieve({
      database_id: id,
    });

    console.log("✅ 這個 ID 是 Database！");
    console.log("Database ID：", database.id);
    console.log("");
  } catch (error) {
    console.log("❌ 不是 Database ID");
    console.log("");
  }
}

checkNotion();